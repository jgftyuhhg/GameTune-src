package com.gametune.control

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.gametune.control.overlay.FpsOverlayService
import com.gametune.control.ui.MainScreen
import com.gametune.control.ui.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

@Composable
fun App(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val refreshOn by vm.refreshOn.collectAsState()
    MainScreen(modifier = Modifier.padding(bottom = 8.dp))
    LaunchedEffect(refreshOn) {
        if (refreshOn) {
            if (Settings.canDrawOverlays(context)) FpsOverlayService.start(context)
        } else FpsOverlayService.stop(context)
    }
}
